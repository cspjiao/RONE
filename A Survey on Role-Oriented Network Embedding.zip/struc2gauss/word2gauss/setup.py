# coding=utf-8
from setuptools import setup
from Cython.Build import cythonize

setup(
    name='embeddings',
    ext_modules=cythonize("embeddings.pyx"),
    zip_safe=False,
)