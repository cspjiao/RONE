# struc2gauss

