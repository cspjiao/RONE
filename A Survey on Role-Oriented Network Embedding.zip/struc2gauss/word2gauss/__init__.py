# import pyximport
#
# pyximport.install()
# from .embeddings import GaussianEmbedding
# from .words import iter_pairs
