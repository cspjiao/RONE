
#include <vector>

extern
//float matching(int n, int m, const std::vector<double>& nzv, const std::vector<int>& nzi, const std::vector<int>& nzj, int* m1, int* m2);
double matching(int n, int m, const std::vector<float>& vA, std::vector<int>& m1, std::vector<int>& m2);

