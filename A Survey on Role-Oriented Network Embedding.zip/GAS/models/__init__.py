from .dgi import DGI
from .sgnn import SGNN
from .gae import GAE