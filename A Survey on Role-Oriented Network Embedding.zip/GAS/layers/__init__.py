from .avgreadout import AvgReadout
from .gcn import GCN
from .discriminator_of_DGI import Discriminator_DGI